<?php
   $hostname = "localhost";
   $username = "root";
   $password = "0000";
   $dbname = "margo";
  
   $conn = mysql_connect($hostname, $username, $password) or die("Connection Fail");
   $db = mysql_select_db($dbname, $conn) or die("db error");
 
   $access_day = date("Ymd");
   $username = $_POST['username'];
   $event_action = $_POST['event_action'];
   $music_title = $_POST['music_title'];
   $current_nice = $_POST['current_nice'];
   $duration_nice = $_POST['duration_nice'];
   $now_date = date("Y-m-d H:i:s");

   $username = stripslashes($username);
   $event_action = stripslashes($event_action);
   $music_title = stripslashes($music_title);
   $current_nice = stripslashes($current_nice);
   $duration_nice = stripslashes($duration_nice);
   $now_date = stripslashes($now_date);
   
   $query = sprintf("INSERT INTO events (access_day, username, event_action, music_title, current_nice, duration_nice, now_date) values('%s', '%s', '%s', '%s', '%s', '%s', '%s')",
    mysql_real_escape_string($access_day),
    mysql_real_escape_string($username),
    mysql_real_escape_string($event_action),
    mysql_real_escape_string($music_title),
    mysql_real_escape_string($current_nice),
    mysql_real_escape_string($duration_nice),
    mysql_real_escape_string($now_date));
   
   $result = mysql_query($query, $conn) or die("Query Error");
   mysqli_close($conn);

    echo $query;
?>