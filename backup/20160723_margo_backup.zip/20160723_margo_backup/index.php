<?php require "login/loginheader.php"; ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet" media="screen">
    <link href="css/main.css" rel="stylesheet" media="screen">
    
    <!-- Wimpy Engine -->
    <script src="wimpy/wimpy.js"></script>
    
    <!-- jQuery CDN -->
    <script src="http://cdn.jsdelivr.net/jquery/3.1.0/jquery.min.js"></script>
    
  </head>
  
  <body>
  <div class="container">
    
    <div class="form-signin">
     <!-- Wimpy Player -->
     <div id="myPlayer" data-skin="/wimpy/wimpy.skins/ramo.tsv" style="display:none" data-wimpyplayer></div>
     
      <!-- scope에는 필요한 권한 범위를 설정해줘야 한다. -->
      <fb:login-button id="facebookButton" scope="
        public_profile,
        user_birthday,
        user_work_history,
        user_education_history,
        user_hometown,
        user_actions.music,
        user_about_me,
        user_religion_politics,
        user_relationships,
        user_relationship_details,
        user_location,
        user_events,
        user_likes" onlogin="checkLoginState();" data-size="xlarge" style="display:block">
      </fb:login-button>

      <div id="status"></div>

    <a href="login/logout.php" class="btn btn-default btn-lg btn-block">Sign out</a>
    </div> <!-- /form-signin -->
  </div> <!-- /container --> 
   
  <script>
    // This is called with the results from from FB.getLoginStatus().
    function statusChangeCallback(response) {
      var facebookButton = document.getElementById('facebookButton'); // Facebook Login 객체 받는 부분
      
      if (response.status === 'connected') {
        console.log("facebook connected");
        
        // Facebook Login 버튼 사라지게 하는 부분
        if(facebookButton.style.display=="block") {
          facebookButton.style.display = "none";
        }
        
        // 정상적으로 로그인이 되면 이리로 들어오게 됨
        getUserInfo();
      }
      else if (response.status === 'not_authorized') {
        // 로그인은 했는데 권한 동의를 아직 하지 않은 경우
        console.log("facebook not_authorized");
        
        // Facebook Login 버튼 나타나게 하는 부분
        if(facebookButton.style.display=="none") {
          facebookButton.style.display = "block";
        }
      }
      else {
        console.log("facebook no login");
        
        // Facebook Login 버튼 나타나게 하는 부분
        if(facebookButton.style.display=="none") {
          facebookButton.style.display = "block";
        }
        
        // 페이스북에 로그인도 안하고 권한도 동의하지 않은 경우
        document.getElementById('status').innerHTML = 'Please log ' + 'into Facebook.';
      }
    }

    // 로그인 상태 체크하기
    function checkLoginState() {
      FB.getLoginStatus(function(response) {
        statusChangeCallback(response);
      });
    }

    window.fbAsyncInit = function() {
      FB.init({
        appId      : '1118860528184621', // ramo appID
        cookie     : true,  // enable cookies to allow the server to access 
                            // the session
        xfbml      : true,  // parse social plugins on this page
        version    : 'v2.2' // use version 2.2
      });

      FB.getLoginStatus(function(response) {
        statusChangeCallback(response);
      });
    };

    // 비동기적으로 SDK 호출하는 부분
    (function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "//connect.facebook.net/en_US/sdk.js";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));

    // 페이스북 로그인이 정상적으로 되면 이 부분을 호출한다.
    function getUserInfo() {
      // 여기에 Graph API 부분의 Query를 넣어준다
      FB.api('/me?fields=name,gender,bio,birthday,education,hometown,sports,inspirational_people,music{name},political,interested_in,work,religion,relationship_status', function(response) {
        $.ajax({
          type: "post",
          url: "cbMusic.php",
          data: JSON.stringify(response),
          dataType: "text",
          success: function(result) {
            console.log("Success");

            // 결과로 받은 음악 리스트를 Wimpy로 넘김
            callMediaPlayer(result);
          },
          error: function(err) {
            console.log(err);
          }
        });
      });
    }
    
    // 전역변수로 선언
    var myPlayerObject;
    var playerInfo;
    var duration_nice;
    var current_nice;
    
    // 플레이어 나타나게 하는 부분
    function callMediaPlayer(result) {
      console.log("consoleMediaPlayer : " + result);
      
      // Wimpy Player가 준비되었을때 호출되는 부분
      wimpy.onReady(function(){
        var myPlayer = document.getElementById('myPlayer'); // Player 객체 받는 부분
        
        // Player 나타나게 하는 부분
        if(myPlayer.style.display=="none") {
          myPlayer.style.display = "block";
        }
        
        // 객체 받는 부분
        myPlayerObject = wimpy.getPlayer("myPlayer");
        playerInfo = myPlayerObject.getStatus();
        
        var prevButton = myPlayerObject.getSkinElement("cmp_rewind");
	    var nextButton = myPlayerObject.getSkinElement("cmp_next");
        
        // 이벤트 리스너 등록하는 부분
        myPlayerObject.addListener("play", this.playPlayer, this);
        myPlayerObject.addListener("pause", this.pausePlayer, this);
        prevButton.addMEL("mouseDown", prevPlayer, this, "Argument for previous button.");
        nextButton.addMEL("mouseDown", nextPlayer, this, "Argument for next button.");
        
        setInterval(pollPlayer, 500);
      });
    }
    
    function pollPlayer(){
      console.log('pollPlayer()');
      var info = myPlayerObject.getStatus();
      
      current_nice = info.current_nice;
      duration_nice = info.duration_nice;
    }
    
    function playPlayer() {
      console.log('playPlayer()');
      
      console.log('current_nice : ' + current_nice);
      console.log('duration_nice : ' + duration_nice);
      
      var info = myPlayerObject.getTrackDataset();
      
      var title; // 노래 제목
      var file; // 파일 경로

      for(var prop in info){
        if(prop == 'title') {
          title = info[prop];
        }

        if(prop == 'file') {
          file = info[file];
        }
      }
      
      insertEvent('jungwoon', 'play', title, current_nice, duration_nice);
    }               
                    
    function pausePlayer() {
      console.log('pausePlayer()');
      
      console.log('current_nice : ' + current_nice);
      console.log('duration_nice : ' + duration_nice);
      
      var info = myPlayerObject.getTrackDataset();
      
      var title; // 노래 제목
      var file; // 파일 경로

      for(var prop in info){
        if(prop == 'title') {
          title = info[prop];
        }

        if(prop == 'file') {
          file = info[file];
        }
      }
      
      insertEvent('jungwoon', 'pause', title, current_nice, duration_nice);
    }
    
    function prevPlayer(obj, pos, arg){
      console.log('prevPlayer()');
      console.log("prevButtonClicked", obj, pos, arg);
      
      var info = myPlayerObject.getTrackDataset();
      
      var title; // 노래 제목
      var file; // 파일 경로

      for(var prop in info){
        if(prop == 'title') {
          title = info[prop];
        }

        if(prop == 'file') {
          file = info[file];
        }
      }
      
      insertEvent('jungwoon', 'prev', title, current_nice, duration_nice);
    }

    function nextPlayer(obj, pos, arg){
      console.log('nextPlayer()');
      console.log("nextButtonClicked", obj, pos, arg);
      
      var info = myPlayerObject.getTrackDataset();
      
      var title; // 노래 제목
      var file; // 파일 경로

      for(var prop in info){
        if(prop == 'title') {
          title = info[prop];
        }

        if(prop == 'file') {
          file = info[file];
        }
      }
      
      insertEvent('jungwoon', 'next', title, current_nice, duration_nice);
    }
    
    // Database에 이벤트 넣는 함수
    function insertEvent(username, event_action, music_title, current_nice, duration_nice) {
      console.log('insertEvent()');
      console.log('username : ' + username);
      console.log('event_action : ' + event_action);
      console.log('music_title : ' + music_title);
      console.log('current_nice : ' + current_nice);
      console.log('duration_nice : ' + duration_nice);
      
      $.ajax({
        type: "post",
        url: "insertEvent.php",
        data: {
          username: username,
          event_action: event_action,
          music_title: music_title,
          current_nice: current_nice,
          duration_nice: duration_nice
        },
        dataType: 'text',
        success: function(html) {
          console.log('insert event success ' + html);
        },
        error: function (textStatus, errorThrown) {
            console.log('insert evnet err');
            console.log(textStatus);
            console.log(errorThrown);
        }
      });
    }

  </script>
    
  </body>
</html>