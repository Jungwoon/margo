<?php
 $access_day = date("Ymd");
 echo $access_day;
?>